/*
 * protocol.h
 */

#ifndef PROTOCOL_H_
#define PROTOCOL_H_

#if defined WIN32
#include <winsock.h>
#else
#define closesocket close
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define BUFFERSZ 64
#define PROTOPORT 57000 // server port number

typedef struct MSG {
    char letter;
    int number;
    char password[33];
} Mess;

#endif /* PROTOCOL_H_ */
