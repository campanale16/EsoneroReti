//Client Socket creation and usage

#include "protocol.h"

void clearwinsock1() {
    #if defined WIN32
    WSACleanup();
    #endif
}

int main() {
#if defined WIN32
    // Initialize Winsock
    WSADATA wsa_data;
    int result = WSAStartup(MAKEWORD(2, 2), &wsa_data);
    if (result != NO_ERROR) {
        printf("Error at WSAStartup()\n");
        return 0;
    }
#endif

    int sock;
    struct sockaddr_in server;
    char input[BUFFERSZ];  // Buffer to store the user input
    Mess message;

    // Create the socket
    sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sock < 0) {
        perror("\nSocket error...");
        exit(-1);
    }

    // Define the server address
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = inet_addr("127.0.0.1"); // Server is on the same machine
    server.sin_port = htons(PROTOPORT);  // Server's port

    // Connect to the server
    if (connect(sock, (struct sockaddr *)&server, sizeof(server)) < 0) {
        perror("\nConnection error...");
        closesocket(sock);
        clearwinsock1();
        exit(-1);
    }

    printf("Connected to server on IP: 127.0.0.1 Port: %d\n", PROTOPORT);

    // Loop to continually read user input and interact with the server
    while (1) {
        // Prompt the user for input (type and password length)
        printf("Enter your choice and password length (e.g., 'n 8') or 'q' to quit:"
        		"n = numeric password\n"
        		"a = alphabetic password\n"
        		"m = mixed password\n"
        		"s = secure password\n"
        		"q = quit\n"
        		"6/32 min & max lenght\n\n");
        fgets(input, sizeof(input), stdin);  // Read input
        input[strcspn(input, "\n")] = '\0';

        // Parse the input (e.g., 'n 8' -> type = 'n', length = 8)
        char type;
        int length;
        if (sscanf(input, " %c%d", &type, &length) != 2) {
            printf("\nInvalid input. Please enter the type and length correctly (e.g., 'n 8').\n");
            continue;
        }


        // If 'q' is entered, quit the program
        if (type == 'q') {
            printf("Exiting the client...\n");
            break;
        }

        // Check that the length is between 6 and 32
        if (length < 6 || length > 32) {
            printf("\nInvalid password length. Must be between 6 and 32 characters.\n");
            continue;
        }

        // Set the message properties (type and length)
        message.letter = type;
        message.number = length;

        // Send the message to the server
        if (send(sock, input, sizeof(input), 0) != sizeof(input)) {
            perror("\nSending error...");
            continue;
        }

        // Wait for the server's response (the generated password)
        int recv_result = recv(sock, input, sizeof(input), 0);
        if (recv_result < 0) {
            perror("\nReceiving error...");
            continue;
        } else if (recv_result == 0) {
            printf("Server disconnected.\n");
            break;  // Exit if server closes the connection
        }

        // Print the received password
        printf("Generated password: %s\n", message.password);
    }

    // Close the socket and clean up
    closesocket(sock);
    clearwinsock1();
    return 0;
}
