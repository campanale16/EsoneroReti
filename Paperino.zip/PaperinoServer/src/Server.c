//Server socket creation and usage


#include "protocol.h"

// Process the message from the client and generate the password
void menu(Mess *msg) {
    srand(time(NULL));
    switch (msg->letter) {
        case 'n':
            generate_numeric(msg->number, msg->password);
            break;
        case 'a':
            generate_alpha(msg->number, msg->password);
            break;
        case 'm':
            generate_mixed(msg->number, msg->password);
            break;
        case 's':
            generate_secure(msg->number, msg->password);
            break;
        default:
            printf("Invalid password type.\n");
            strcpy(msg->password, "Invalid input");
    }
}

int main (int argc, char* argv[]) {

#if defined WIN32
	// Initialize Winsock
	WSADATA wsa_data; // @suppress("Type cannot be resolved")
	int result = WSAStartup(MAKEWORD(2,2), &wsa_data);
	if (result != NO_ERROR) {
		printf("Error at WSAStartup()\n");
		return 0;
	}
#endif

    int sock;
    struct sockaddr_in server;
    int port = PROTOPORT;
    char input[BUFFERSZ];  // Input buffer to store the user input

    // Socket creation
    sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sock < 0) {
        perror("\nSocket error...");
        exit(-1);
    }

    // Binding the socket to the address
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = inet_addr("127.0.0.1");
    server.sin_port = htons(port);

    if (bind(sock, (struct sockaddr_in *)&server, sizeof(server)) < 0) {
        perror("\nBinding error...");
        exit(-1);
    }

    // Listen for incoming connections
    if (listen(sock, QLENGTH) < 0) {
        perror("\nListening error...");
        exit(-1);
    }

    struct sockaddr_in clientsock;
    int client_add;
    int client_len;
    Mess message;

    printf("\nWaiting for connections...");

    while (1) {
        client_len = sizeof(clientsock);

        if ((client_add = accept(sock, (struct sockaddr *)&clientsock, &client_len)) < 0) {
            perror("\nAcceptance error...");
            continue;// Retry if acceptance fails
        }

        printf("Client connected, IP: %s Port: %d\n", inet_ntoa(clientsock.sin_addr), ntohs(clientsock.sin_port));
        printf("Waiting for input...");

        while (1){

            // Read input from the client
            int bytes_received = recv(client_add, input, sizeof(input), 0);
            if (bytes_received <= 0) {
               perror("\nReceiving error...");
               break;
               closesocket(client_add);
               clearwinsock();
            }

            // Parse the input (e.g., 'n 8')
            char type;
            int length;
            sscanf(input, " %c%d", &type, &length);

            // Validate the password length
            if (length < 6 || length > 32) {
            	printf("\nInvalid password length. Must be between 6 and 32 characters.\n");
                strcpy(message.password, "Invalid length");
            } else {
            // Set the message properties for password generation
            message.letter = type;
            message.number = length;

            // Special case for quitting
            if (message.letter == 'q') {
            printf("\nExiting the password generator...\n");
            break;
            }

            // Generate the password based on type
            menu(&message);

            // Send the generated password back to the client
            if (send(client_add, &message.password, sizeof(message), 0) < 0) {
                perror("\nSending response error...");
            } else {
                printf("Sent password: %s\n", message.password);
            }
            }
        }

    }

    closesocket(sock);
    clearwinsock();
    return 0;
    }
