

#ifndef FUNCTS_H_
#define FUNCTS_H_

#include "protocol.h"

void clearwinsock() {
    #if defined WIN32
    WSACleanup();
    #endif
}

// Function to generate a numeric password
void generate_numeric(int length, char* password) {
    const char digits[] = "0123456789";
    for (int i = 0; i < length; i++) {
        password[i] = digits[rand() % 10];
    }
    password[length] = '\0';
}

// Function to generate an alphabetical password
void generate_alpha(int length, char* password) {
    const char letters[] = "abcdefghijklmnopqrstuvwxyz";
    for (int i = 0; i < length; i++) {
        password[i] = letters[rand() % 26];
    }
    password[length] = '\0';
}

// Function to generate a mixed password (letters + digits)
void generate_mixed(int length, char* password) {
    const char alphanumeric[] = "abcdefghijklmnopqrstuvwxyz0123456789";
    for (int i = 0; i < length; i++) {
        password[i] = alphanumeric[rand() % 36];
    }
    password[length] = '\0';
}

// Function to generate a secure password (uppercase, lowercase, digits, symbols)
void generate_secure(int length, char* password) {
    const char secure[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+";
    for (int i = 0; i < length; i++) {
        password[i] = secure[rand() % strlen(secure)];
    }
    password[length] = '\0';
}



#endif /* FUNCTS_H_ */
